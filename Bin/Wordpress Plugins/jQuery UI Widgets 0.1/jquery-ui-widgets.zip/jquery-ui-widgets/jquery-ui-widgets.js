jQuery(document).ready(function($) {
	$( ".jquiw-tabs" ).tabs();
});